package com.example.newsappusingapi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import org.apache.commons.io.IOUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;


public class MainActivity extends AppCompatActivity {
    Button buttonSelect;
    ImageButton ib_back, ib_next;
    TextView tv_categories, tv_title, tv_PublishedAt, tv_pageCount;
    ProgressBar progressBar;
    ImageView imageView;
    EditText description;
    int index = 0;
    int size;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        buttonSelect = findViewById(R.id.buttonSelect);
        tv_categories = (TextView) findViewById(R.id.tv_categories);
        progressBar = (ProgressBar) findViewById(R.id.progressBar);
        description = (EditText) findViewById(R.id.et_description);
        tv_title = (TextView) findViewById(R.id.tv_title);
        tv_PublishedAt = (TextView) findViewById(R.id.tv_PublishedAt);
        ib_back = (ImageButton) findViewById(R.id.ib_back);
        ib_next = (ImageButton) findViewById(R.id.ib_next);
        imageView = (ImageView) findViewById(R.id.imageView);
        tv_pageCount = (TextView) findViewById(R.id.tv_pageCount);
        ib_back.setVisibility(View.INVISIBLE);
        ib_next.setVisibility(View.INVISIBLE);
        ib_next.setAlpha(127);
        ib_back.setAlpha(127);


        progressBar.setVisibility(View.INVISIBLE);

        final CharSequence[] items = new CharSequence[]{"Business", "Entertainment", "General", "Health", "Science", "Sports", "Technology"};

        buttonSelect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isConnected()) {
                    Toast.makeText(MainActivity.this, "Internet Connection", Toast.LENGTH_SHORT).show();
                    AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                    builder.setTitle("Choose Category");
                    builder.setItems(items, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            tv_categories.setText(items[which].toString());
                            progressBar.setVisibility(View.VISIBLE);
                            new GetSimpleAsync().execute("https://newsapi.org/v2/top-headlines?category=" + items[which] + "&apiKey=39f746c057f2488eb3876c9be74d9837");
                        }
                    });
                    AlertDialog Alert = builder.create();
                    Alert.show();

                } else {
                    Toast.makeText(MainActivity.this, "No Internet Connection", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private boolean isConnected() {
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
        if (networkInfo == null || !networkInfo.isConnected() ||
                (networkInfo.getType() != ConnectivityManager.TYPE_WIFI
                        && networkInfo.getType() != ConnectivityManager.TYPE_MOBILE)) {
            return false;
        }
        return true;
    }

    private class GetSimpleAsync extends AsyncTask<String, Void, ArrayList<News>> {
        @Override
        protected ArrayList<News> doInBackground(String... params) {
            String json = null;
            ArrayList<News> result = new ArrayList<>();
            HttpURLConnection connection = null;
            try {
                URL url = new URL(params[0]);
                connection = (HttpURLConnection) url.openConnection();
                connection.connect();
                if (connection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    json = IOUtils.toString(connection.getInputStream(), "utf-8");
                    JSONObject root = new JSONObject(json);
                    JSONArray News = root.getJSONArray("articles");
                    for (int i = 0; i < News.length(); i++) {
                        JSONObject personJSON = News.getJSONObject(i);
                        News news = new News();
                        news.title = personJSON.getString("title");
                        news.publishedAt = personJSON.getString("publishedAt");
                        news.urltoImage = personJSON.getString("urlToImage");
                        news.description = personJSON.getString("description");
                        result.add(news);
                    }
                }
            } catch (IOException ex) {
                ex.printStackTrace();
            } catch (JSONException ex) {
                ex.printStackTrace();
            } finally {
                if (connection != null) {
                    connection.disconnect();
                }
            }
            return result;
        }

        @Override
        protected void onPostExecute(final ArrayList<News> json) {
            progressBar.setVisibility(View.INVISIBLE);
            size = json.size();
            if (size > 20) {
                size = 20;
            }
            if (json != null) {
                ib_back.setVisibility(View.VISIBLE);
                ib_next.setVisibility(View.VISIBLE);
                ib_next.setAlpha(255);
                ib_back.setAlpha(255);
                DisplayFunction(json);

                ib_next.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        index++;
                        if (index <= size) {
                            if (index == size) {
                                index = 0;
                            }
                            DisplayFunction(json);
                        }
                    }
                });

                ib_back.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        index--;
                        if (index == -1) {
                            index = size - 1;
                        }
                        DisplayFunction(json);
                    }

                });

            } else {
                Toast.makeText(MainActivity.this, "No News Found", Toast.LENGTH_SHORT).show();
            }
        }
    }

    public void DisplayFunction(ArrayList<News> json) {
        if (json.get(index).description.equals("null")) {
            description.setText("No Description");
        } else {
            description.setText(json.get(index).description);
        }
        if (json.get(index).title.equals("null")) {
            description.setText("No Title");
        } else {
            tv_title.setText(json.get(index).title);
        }

        if (json.get(index).publishedAt.equals("null")) {
            description.setText("No published date");
        } else {
            tv_title.setText(json.get(index).publishedAt);
        }

        if (json.get(index).urltoImage.equals("null") || json.get(index).urltoImage == null) {

        } else {
            Picasso.get().load(json.get(index).urltoImage).into(imageView);
        }
        tv_pageCount.setText((index + 1) + " Out of " + size);
    }


}